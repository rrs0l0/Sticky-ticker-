const noteContainer = document.getElementById('note-container');
const addNoteBtn = document.getElementById('add-note-btn');
const noteText = document.getElementById('note-text');

// Sample bad words list (replace with your desired list)
const badWords = ["bad", "terrible", "nasty"];

// Function to censor bad words (basic implementation)
function censorText(text) {
let censoredText = text;
for (const badWord of badWords) {
const regex = new RegExp(badWord, 'gi'); // Case-insensitive replacement
censoredText = censoredText.replace(regex, '***');
}
return censoredText;
}

addNoteBtn.addEventListener('click', () => {
const noteTextValue = noteText.value.trim(); // Get the note text with leading/trailing spaces removed

if (noteTextValue) {
const censoredNoteText = censorText(noteTextValue);

// Create a new note element
const newNote = document.createElement('div');
newNote.classList.add('note');

// Add content to the note element (text, timestamp, etc.)
const noteTextElement = document.createElement('p');
noteTextElement.textContent = censoredNoteText;

const timestampElement = document.createElement('span');
timestampElement.classList.add('timestamp');
timestamp
